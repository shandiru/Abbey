import React, { useState, useRef } from "react";

const HOURS = [
  { day: "Monday", time: "9:30 am – 5:30 pm" },
  { day: "Tuesday", time: "9:30 am – 5:30 pm" },
  { day: "Wednesday", time: "9:30 am – 5:30 pm" },
  { day: "Thursday", time: "9:30 am – 5:30 pm" },
  { day: "Friday", time: "9:30 am – 5:30 pm" },
  { day: "Saturday", time: "9:30 am – 2:30 pm" },
  { day: "Sunday", time: "Closed" },
];

const SERVICES = [
  "MOT Testing", "Vehicle Service", "Diagnostics", "Brake Service",
  "Suspension", "Air Conditioning", "Tyre Alignment", "Clutch Repair",
  "Timing System", "Fleet Management", "Commercial Van Services",
];

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
const PHONE_REGEX = /^(?:\+44|0)[1-9]\d{8,9}$/;

export default function ContactSection() {
  const formRef = useRef(null);
  const [status, setStatus] = useState({ state: "idle", message: "" });
  const [touched, setTouched] = useState({});
  const [errors, setErrors] = useState({});
  const [selectedService, setSelectedService] = useState("");

  const validateField = (name, value) => {
    switch (name) {
      case "name":
        if (!value?.trim()) return "Please enter your name.";
        if (value.trim().length < 2) return "Name looks too short.";
        return "";
      case "email":
        if (!value?.trim()) return "Please enter your email.";
        if (!EMAIL_REGEX.test(value.trim())) return "Enter a valid email address.";
        return "";
      case "phone":
        if (!value) return "";
        if (!PHONE_REGEX.test(value.trim()))
          return "Enter a valid phone (e.g. 07912 345 678 or +44 7912 345 678).";
        return "";
      case "message":
        if (!value?.trim()) return "Please tell us about the issue.";
        if (value.trim().length < 10) return "Message should be at least 10 characters.";
        return "";
      case "service":
        if (!value) return "Please select a service.";
        return "";
      default:
        return "";
    }
  };

  const validateForm = (form) => {
    const fd = new FormData(form);
    const fields = ["name", "email", "phone", "message", "service"];
    const newErrors = {};
    fields.forEach((f) => {
      const msg = validateField(f, fd.get(f));
      if (msg) newErrors[f] = msg;
    });
    if (fd.get("website")) newErrors.website = "Bot detected.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched((t) => ({ ...t, [name]: true }));
    const msg = validateField(name, value);
    setErrors((prev) => ({ ...prev, [name]: msg }));
  };

  const sendWhatsAppMessage = (e) => {
    e.preventDefault();
    if (!formRef.current) return;
    if (!validateForm(formRef.current)) {
      setStatus({ state: "error", message: "Please fix the highlighted fields and try again." });
      return;
    }
    const formData = new FormData(formRef.current);
    const name = formData.get("name");
    const email = formData.get("email");
    const phone = formData.get("phone");
    const message = formData.get("message");
    const messageText = `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nService: ${selectedService}\nMessage: ${message}`;
    const encodedMessage = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/+447850953737?text=${encodedMessage}`;
    window.open(whatsappUrl, "_blank");
    setStatus({ state: "success", message: "Thanks! We'll get back to you shortly." });
    formRef.current.reset();
    setTouched({});
    setErrors({});
    setSelectedService("");
  };

  const inputBase = "w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#3B82F6] transition-all duration-200 text-sm";
  const inputDark = "bg-[#0F172A] dark:bg-[#0F172A] light:bg-white text-white dark:text-white light:text-[#0F172A] border-[#3D4B5E] dark:border-[#3D4B5E] light:border-[#CBD5E1] placeholder-[#CBD5E1]/40 dark:placeholder-[#CBD5E1]/40 light:placeholder-[#3D4B5E]/40";
  const inputError = "border-[#3B82F6]";

  return (
    <section
      id="contact"
      className="bg-[#0F172A] dark:bg-[#0F172A] light:bg-slate-50 py-20 px-4 transition-colors duration-300"
    >
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <span className="inline-block text-[#3B82F6] text-xs font-bold uppercase tracking-widest mb-3">
            Get In Touch
          </span>
          <h2 data-aos="fade-up" className="text-2xl md:text-3xl font-bold text-white dark:text-white light:text-[#0F172A]">
            Ready to Get Your Car Fixed?
          </h2>
          <p data-aos="fade-up" className="text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E] mt-3 max-w-2xl mx-auto text-sm">
            Contact us to schedule a mobile repair service, ask questions, or request a quote. Our team is ready to help.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left — Contact Info */}
          <div
            data-aos="fade-right"
            className="bg-[#1E293B] dark:bg-[#1E293B] light:bg-white rounded-2xl border border-[#3D4B5E] p-6 md:p-8 transition-colors duration-300"
          >
            <h3 className="text-base font-bold text-white dark:text-white light:text-[#0F172A] mb-6 flex items-center gap-2">
              <span className="w-4 h-0.5 bg-[#3B82F6]" />
              Contact Information
            </h3>
            <div className="space-y-6 text-sm">
              <div>
                <a href="https://maps.app.goo.gl/d9dqa5CSawPFofzKA" target="_blank" rel="noreferrer" className="group">
                  <p className="text-[#3B82F6] font-bold text-[10px] uppercase tracking-wider mb-1">Address</p>
                  <address className="not-italic text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E] group-hover:text-white transition-colors leading-relaxed">
                    29 Church St, Old Basford<br />
                    Nottingham NG6 0GA<br />
                    United Kingdom
                  </address>
                </a>
              </div>
              <div>
                <p className="text-[#3B82F6] font-bold text-[10px] uppercase tracking-wider mb-1">Phone</p>
                <a href="tel:+447846953888" className="text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E] hover:text-white transition-colors">
                  07846 953888
                </a>
              </div>
              <div>
                <p className="text-[#3B82F6] font-bold text-[10px] uppercase tracking-wider mb-2">Opening Hours</p>
                <ul className="divide-y divide-[#3D4B5E] border border-[#3D4B5E] rounded-xl overflow-hidden">
                  {HOURS.map(({ day, time }) => (
                    <li
                      key={day}
                      className="grid grid-cols-2 gap-4 px-4 py-2 text-xs bg-[#0F172A]/40 dark:bg-[#0F172A]/40 light:bg-slate-50/50"
                    >
                      <span className="text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E]">{day}</span>
                      <span className={`text-right font-semibold ${time === "Closed" ? "text-red-400" : "text-white dark:text-white light:text-[#0F172A]"}`}>
                        {time}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Right — Form */}
          <div
            data-aos="fade-left"
            className="bg-[#1E293B] dark:bg-[#1E293B] light:bg-white rounded-2xl border border-[#3D4B5E] p-6 md:p-8 transition-colors duration-300"
          >
            <h3 className="text-base font-bold text-white dark:text-white light:text-[#0F172A] mb-6 flex items-center gap-2">
              <span className="w-4 h-0.5 bg-[#3B82F6]" />
              Send Us a Message
            </h3>

            {status.state === "success" && (
              <div className="mb-4 p-3 rounded-lg bg-green-900/30 border border-green-700/50 text-green-400 text-sm">
                {status.message}
              </div>
            )}
            {status.state === "error" && (
              <div className="mb-4 p-3 rounded-lg bg-red-900/30 border border-red-700/50 text-red-400 text-sm">
                {status.message}
              </div>
            )}

            <form ref={formRef} onSubmit={sendWhatsAppMessage} className="space-y-4" noValidate>
              <input type="text" name="website" tabIndex="-1" autoComplete="off" className="hidden" />

              {/* Name */}
              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Your name*"
                  required
                  onBlur={handleBlur}
                  aria-invalid={!!errors.name}
                  className={`${inputBase} ${inputDark} ${errors.name && touched.name ? inputError : ""}`}
                />
                {errors.name && touched.name && (
                  <p className="mt-1 text-xs text-red-400">{errors.name}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="your.email@example.com*"
                  required
                  inputMode="email"
                  onBlur={handleBlur}
                  className={`${inputBase} ${inputDark} ${errors.email && touched.email ? inputError : ""}`}
                />
                {errors.email && touched.email && (
                  <p className="mt-1 text-xs text-red-400">{errors.email}</p>
                )}
              </div>

              {/* Service */}
              <div>
                <select
                  name="service"
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  onBlur={handleBlur}
                  className={`${inputBase} ${inputDark} ${errors.service && touched.service ? inputError : ""}`}
                  required
                >
                  <option value="">-- Select a Service --</option>
                  {SERVICES.map((service) => (
                    <option key={service} value={service}>{service}</option>
                  ))}
                </select>
                {errors.service && touched.service && (
                  <p className="mt-1 text-xs text-red-400">{errors.service}</p>
                )}
              </div>

              {/* Phone */}
              <div>
                <input
                  type="tel"
                  name="phone"
                  placeholder="07912 345 678 or +44 7912 345 678*"
                  inputMode="tel"
                  onBlur={handleBlur}
                  className={`${inputBase} ${inputDark} ${errors.phone && touched.phone ? inputError : ""}`}
                />
                {errors.phone && touched.phone && (
                  <p className="mt-1 text-xs text-red-400">{errors.phone}</p>
                )}
              </div>

              {/* Message */}
              <div>
                <textarea
                  name="message"
                  placeholder="Tell us about your car issue*"
                  rows="4"
                  required
                  onBlur={handleBlur}
                  className={`${inputBase} ${inputDark} resize-none ${errors.message && touched.message ? inputError : ""}`}
                />
                {errors.message && touched.message && (
                  <p className="mt-1 text-xs text-red-400">{errors.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={status.state === "sending"}
                className="w-full text-white font-semibold bg-[#3B82F6] hover:bg-blue-400 py-3 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 hover:shadow-[0_0_24px_rgba(59,130,246,0.4)] disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {status.state === "sending" ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                    </svg>
                    Sending…
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12h15m0 0l-6.75-6.75M19.5 12l-6.75 6.75" />
                    </svg>
                    Send via WhatsApp
                  </>
                )}
              </button>

              <p className="text-xs text-[#CBD5E1]/50 text-center leading-relaxed">
                Same-day appointments often available · No obligation consultation
              </p>
              <p className="text-xs text-center text-[#CBD5E1]/40">
                By submitting this form, you agree to us processing your details in line with our Privacy Policy.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}