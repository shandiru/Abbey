import React from 'react';
import { Facebook, Instagram, Clock, ArrowRight } from 'lucide-react';

const PHONE = import.meta.env.VITE_PHONE_NUMBER;
const PHONE_TEL = import.meta.env.VITE_PHONE_TEL;
const EMAIL = import.meta.env.VITE_EMAIL;

const UniqueFooter = () => {
  const openingHours = [
    { day: "Mon - Thu", time: "9 AM – 5 PM" },
    { day: "Friday", time: "9 AM – 5 PM" },
    { day: "Sat - Sun", time: "Closed" },
  ];

  const handleNavClick = (e, path) => {
    if (path.startsWith('#')) {
      e.preventDefault();
      const element = document.querySelector(path);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.location.href = '/' + path;
      }
    }
  };

  return (
    <footer className="bg-[#1E293B] dark:bg-[#1E293B] light:bg-[#1E293B] pt-20 pb-10 relative overflow-hidden border-t border-[#3D4B5E]">
      {/* Background watermark text */}
      <div className="absolute bottom-[-8%] left-0 w-full pointer-events-none select-none overflow-hidden">
        <h2 className="text-[15vw] font-black text-white/[0.02] uppercase leading-none tracking-tighter whitespace-nowrap">
          TK Automotive
        </h2>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">

          {/* Brand */}
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <img
                src="/logo.jpg"
                alt="TK Automotive Logo"
                className="w-full h-full rounded-xl border border-[#3D4B5E]"
              />
            </div>
            <p className="text-[#CBD5E1] text-sm leading-relaxed mb-8">
              Professional ECU remapping, advanced diagnostics, and precision mechanical solutions for the Isle of Man.
            </p>
            <div className="flex gap-3">
              {[Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="https://web.facebook.com/tkautomotiveiom/"
                  className="w-10 h-10 rounded-lg border border-[#3D4B5E] flex items-center justify-center hover:bg-[#3B82F6] hover:border-[#3B82F6] transition-all duration-300 group"
                >
                  <Icon size={16} className="text-[#CBD5E1] group-hover:text-white transition-colors" />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8 flex items-center gap-2">
              <span className="w-4 h-0.5 bg-[#3B82F6]" />
              Quick Navigation
            </h4>
            <ul className="space-y-3">
              {[
                { name: 'Home', path: '/' },
                { name: 'About Us', path: '#about' },
                { name: 'ECU Remapping', path: '/ecu-remapping-tuning' },
                { name: 'Diagnostics', path: '/diagnostics' },
                { name: 'Contact Us', path: '#contact' },
              ].map((link) => (
                <li key={link.name}>
                  <a
                    href={link.path}
                    onClick={(e) => handleNavClick(e, link.path)}
                    className="text-[#CBD5E1] hover:text-white transition-all duration-300 flex items-center gap-2 group text-sm"
                  >
                    <ArrowRight
                      size={12}
                      className="text-[#3B82F6] opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300"
                    />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8 flex items-center gap-2">
              <span className="w-4 h-0.5 bg-[#3B82F6]" />
              Contact Info
            </h4>
            <ul className="space-y-5 text-[#CBD5E1] text-sm">
              <li className="flex flex-col">
                <span className="text-[#3B82F6] font-bold text-[10px] mb-1 uppercase tracking-wider">Location</span>
                Lower Ballacottier, Onchan IM4 5BQ,<br />Isle of Man
              </li>
              <li className="flex flex-col">
                <span className="text-[#3B82F6] font-bold text-[10px] mb-1 uppercase tracking-wider">Phone</span>
                <a href={PHONE_TEL} className="hover:text-white transition-colors">{PHONE}</a>
              </li>
              <li className="flex flex-col">
                <span className="text-[#3B82F6] font-bold text-[10px] mb-1 uppercase tracking-wider">Email</span>
                <a href={`mailto:${EMAIL}`} className="hover:text-white transition-colors text-[13px]">{EMAIL}</a>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8 flex items-center gap-2">
              <span className="w-4 h-0.5 bg-[#3B82F6]" />
              Workshop Hours
            </h4>
            <div className="space-y-3">
              {openingHours.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center border-b border-[#3D4B5E] pb-2">
                  <span className="text-[#CBD5E1] text-sm">{item.day}</span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    item.time === 'Closed'
                      ? 'text-red-400 bg-red-900/20 border border-red-900/30'
                      : 'text-white bg-[#3B82F6]/10 border border-[#3B82F6]/30'
                  }`}>
                    {item.time}
                  </span>
                </div>
              ))}
              <p className="text-[10px] text-[#CBD5E1]/60 italic mt-4 flex items-center gap-2">
                <Clock size={11} className="text-[#3B82F6]" />
                Appointments required for dyno & remapping.
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-[#3D4B5E] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#CBD5E1]/50 text-[10px] uppercase tracking-widest font-medium">
            © 2026 TK Automotive. All rights reserved.
          </p>
          <p className="text-[#CBD5E1]/50 text-[10px] uppercase tracking-widest font-medium">
            Powered by{" "}
            <a
              href="https://www.ansely.co.uk/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#3B82F6] text-[#3B82F6]/70 transition-colors"
            >
              Ansely
            </a>
          </p>
          <div className="flex flex-wrap justify-center gap-5 text-[10px] uppercase tracking-widest font-bold">
            {['Remapping', 'Diagnostics', 'DPF/AdBlue', 'Repairs', 'Privacy'].map((link, i) => (
              <a
                key={i}
                href={`/${link.toLowerCase().replace('/', '-')}`}
                className="text-[#CBD5E1]/40 hover:text-[#3B82F6] transition-colors"
              >
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default UniqueFooter;