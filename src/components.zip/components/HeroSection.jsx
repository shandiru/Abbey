import React from "react";
import { FaPhone, FaMapMarkerAlt, FaClock, FaTools, FaUser } from "react-icons/fa";

const HeroSection = () => {
  const stats = [
    { title: "20+ Years Experience", icon: <FaClock className="h-6 w-6 text-[#3B82F6]" /> },
    { title: "1000+ Customers", icon: <FaUser className="h-6 w-6 text-[#3B82F6]" /> },
    { title: "Specified Viezu Dealer", icon: <FaMapMarkerAlt className="h-6 w-6 text-[#3B82F6]" /> },
    { title: "Bespoke Custom Remapping", icon: <FaTools className="h-6 w-6 text-[#3B82F6]" /> },
  ];

  return (
    <section
      className="relative overflow-hidden bg-[#0F172A] dark:bg-[#0F172A] light:bg-slate-100 transition-colors duration-300"
      id="home"
    >
      {/* Subtle grid pattern */}
      <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.03] light:opacity-[0.06]"
        style={{
          backgroundImage: `linear-gradient(#3B82F6 1px, transparent 1px), linear-gradient(90deg, #3B82F6 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />
      {/* Blue glow */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#3B82F6]/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">

          {/* LEFT CONTENT */}
          <div className="space-y-6 text-left" data-aos="fade-right">
            <div className="inline-flex items-center gap-2 bg-[#3B82F6]/10 border border-[#3B82F6]/30 rounded-full px-4 py-1.5">
              <span className="w-2 h-2 rounded-full bg-[#3B82F6] animate-pulse" />
              <span className="text-[#3B82F6] text-xs font-semibold uppercase tracking-wider">Now Accepting Bookings</span>
            </div>

            <h1 className="text-4xl md:text-5xl xl:text-6xl font-black leading-tight text-white dark:text-white light:text-[#0F172A]">
              <span className="text-[#3B82F6]">Broadway</span>
              <br />
              <span>Remapping</span>
            </h1>

            <p className="text-lg text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E] font-medium">
              Professional ECU Remapping & Vehicle Tuning
            </p>

            <p className="text-base text-[#CBD5E1]/80 dark:text-[#CBD5E1]/80 light:text-[#3D4B5E]/80 max-w-lg leading-relaxed">
              Boost performance, improve fuel efficiency, and get expert tuning
              services across North Wales and the North West.
            </p>

            <div className="flex flex-col sm:flex-row gap-3" data-aos="fade-up">
              <a
                href="tel:+447392791919"
                className="inline-flex items-center justify-center gap-2 text-sm bg-[#3B82F6] hover:bg-blue-400 text-white h-11 rounded-lg px-6 font-semibold transition-all duration-300 hover:shadow-[0_0_24px_rgba(59,130,246,0.5)]"
              >
                <FaPhone className="h-4 w-4" />
                Call Now
              </a>
              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 text-sm border border-[#3D4B5E] text-[#CBD5E1] hover:text-white hover:border-[#3B82F6] h-11 rounded-lg px-6 font-semibold transition-all duration-300 hover:bg-[#1E293B]"
              >
                View Services
              </a>
              <a
                href="https://viezu.com/dealer?id=eaa32c96f620053cf442ad32258076b9"
                className="inline-flex items-center justify-center gap-2 text-sm border border-[#3D4B5E] text-[#CBD5E1] hover:text-white hover:border-[#3B82F6] h-11 rounded-lg px-6 font-semibold transition-all duration-300 hover:bg-[#1E293B]"
              >
                Vehicle Look Up
              </a>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg transition hover:bg-[#1E293B] w-fit" data-aos="zoom-in">
              <FaMapMarkerAlt className="h-5 w-5 text-[#3B82F6] flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white dark:text-white light:text-[#0F172A]">Location</p>
                <p className="text-sm text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E]">
                  Que Sera, Pentre Hill, Flint, UK
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT IMAGE */}
          <div className="relative w-full" data-aos="fade-left">
            <div className="aspect-video sm:aspect-[4/3] w-full relative rounded-2xl overflow-hidden shadow-2xl border border-[#3D4B5E] transition-all duration-300 hover:shadow-[0_12px_40px_rgba(59,130,246,0.3)] hover:border-[#3B82F6]/50">
              <img
                src="/newhero.jpg"
                alt="Dyno Remapping"
                className="object-cover absolute inset-0 h-full w-full"
              />
              {/* Overlay shimmer */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A]/40 to-transparent" />
            </div>
          </div>
        </div>

        {/* STATS */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="flex flex-col items-center justify-center bg-[#1E293B] dark:bg-[#1E293B] light:bg-white border border-[#3D4B5E] hover:border-[#3B82F6]/50 p-6 rounded-xl shadow transition-all duration-300 hover:shadow-[0_8px_24px_rgba(59,130,246,0.2)] min-h-[110px]"
              data-aos="zoom-in"
              data-aos-delay={index * 100}
            >
              <div className="flex items-center justify-center mb-3 w-10 h-10 rounded-lg bg-[#3B82F6]/10 border border-[#3B82F6]/20">
                {stat.icon}
              </div>
              <p className="text-white dark:text-white light:text-[#0F172A] font-bold text-sm text-center">{stat.title}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;