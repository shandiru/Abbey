import React, { useState, useEffect, useMemo } from 'react';

const ExpandingCards = () => {
  const [activeCard, setActiveCard] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  const TIMER_DURATION = 5000;
  const VISIBLE_COUNT = 3;

  const cards = [
    {
      number: '01',
      title: 'Car Park Ding Removal',
      description: 'Smooth out annoying car park dings quickly using precise PDR techniques, restoring your panels to factory finish without paint.',
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Quick Fix · Factory Finish',
    },
    {
      number: '02',
      title: 'Small Dent Removal',
      description: "Remove small dents from doors, panels, or bumpers efficiently with Paintless Dent Removal, keeping your car's original paint intact.",
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Precision Repairs · Scratch-Free',
    },
    {
      number: '03',
      title: 'Large Dent Removal',
      description: 'Restore large dents seamlessly using advanced PDR tools, ensuring your vehicle looks flawless without repainting.',
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Body Panel Specialists · Factory Finish',
    },
    {
      number: '04',
      title: 'Complex Large Dent Repair',
      description: 'Handle intricate and deep dents across multiple panels with expert PDR techniques for a smooth, paint-free finish.',
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Expert Panel Work · Complex Specialists',
    },
    {
      number: '05',
      title: 'Crease Dent Repair',
      description: "Remove sharp creases and lines from your vehicle's bodywork using advanced PDR, restoring curves to their original shape.",
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Crease Specialist · Factory Finish',
    },
    {
      number: '06',
      title: 'Bumper Dent Removal',
      description: 'Fix dents and dings on plastic or metal bumpers without repainting, keeping your car looking like new.',
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Dent Repair · Bumper Specialist · Quick & Clean',
    },
    {
      number: '07',
      title: 'Hail Damage Removal',
      description: 'Quickly remove multiple hail dents across the roof, bonnet, and panels using advanced PDR techniques — no repainting needed.',
      image: 'https://framerusercontent.com/images/2d6UchpU1MbzUJ2Yeq8GV9oVUE.jpeg?width=3840&height=2160',
      tags: 'Paintless Restoration · Roof & Bonnet Specialists · Factory Finish',
    },
  ];

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const visibleCards = useMemo(() => {
    if (isMobile) return [{ ...cards[activeCard], originalIndex: activeCard }];
    const result = [];
    for (let i = 0; i < VISIBLE_COUNT; i++) {
      const index = (activeCard + i) % cards.length;
      result.push({ ...cards[index], originalIndex: index });
    }
    return result;
  }, [activeCard, isMobile]);

  useEffect(() => {
    setProgress(0);
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + (100 / (TIMER_DURATION / 50));
        return next >= 100 ? 100 : next;
      });
    }, 50);
    const cardTimer = setTimeout(() => {
      setActiveCard((prev) => (prev + 1) % cards.length);
    }, TIMER_DURATION);
    return () => { clearInterval(progressInterval); clearTimeout(cardTimer); };
  }, [activeCard]);

  const handleCardClick = (originalIndex) => {
    if (originalIndex !== activeCard) {
      setActiveCard(originalIndex);
      setProgress(0);
    }
  };

  const handlePrevious = () => { setActiveCard((prev) => (prev - 1 + cards.length) % cards.length); setProgress(0); };
  const handleNext = () => { setActiveCard((prev) => (prev + 1) % cards.length); setProgress(0); };

  return (
    <div
      id="services"
      className="w-full min-h-screen scroll-m-20 bg-[#0F172A] dark:bg-[#0F172A] light:bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-6 md:p-8 transition-colors duration-500"
    >
      {/* Header */}
      <div className="mb-10 md:mb-14 text-center">
        <span className="text-[#3B82F6] text-xs font-bold uppercase tracking-widest">What We Offer</span>
        <h2 className="text-white dark:text-white light:text-[#0F172A] text-2xl sm:text-3xl md:text-4xl font-bold uppercase tracking-widest transition-colors mt-2">
          Our Services
        </h2>
        <p className="text-[#CBD5E1] dark:text-[#CBD5E1] light:text-[#3D4B5E] text-xs mt-2">
          Showing {activeCard + 1} of {cards.length}
        </p>
      </div>

      {/* Cards Container */}
      <div className="w-full max-w-[1400px] mb-6 md:mb-0">
        {isMobile ? (
          <div className="relative">
            <button
              onClick={handlePrevious}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-30 bg-[#1E293B] border border-[#3D4B5E] rounded-full p-3 shadow-lg hover:border-[#3B82F6] transition-colors"
              aria-label="Previous"
            >
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              onClick={handleNext}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-30 bg-[#1E293B] border border-[#3D4B5E] rounded-full p-3 shadow-lg hover:border-[#3B82F6] transition-colors"
              aria-label="Next"
            >
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </button>

            {/* Mobile Card */}
            <div className="relative overflow-hidden rounded-2xl bg-[#1E293B] border border-[#3D4B5E] shadow-xl min-h-[500px] sm:min-h-[600px]">
              {/* Progress bar */}
              <div className="absolute top-0 left-0 w-full h-1 bg-[#3D4B5E]/40 overflow-hidden z-20">
                <div className="absolute left-0 top-0 h-full bg-[#3B82F6] transition-all duration-100 ease-linear" style={{ width: `${progress}%` }} />
              </div>
              <div className="p-6 sm:p-8 flex flex-col gap-5 h-full">
                <div>
                  <div className="text-5xl font-black text-white/10">{cards[activeCard].number}</div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white mt-2">{cards[activeCard].title}</h3>
                </div>
                <p className="text-[#CBD5E1] text-sm leading-relaxed">{cards[activeCard].description}</p>
                <div className="w-full h-48 sm:h-64 overflow-hidden rounded-xl border border-[#3D4B5E]">
                  <img src={cards[activeCard].image} alt={cards[activeCard].title} className="w-full h-full object-cover" />
                </div>
                <div className="text-[10px] font-bold tracking-widest text-[#3B82F6] uppercase mt-auto">
                  {cards[activeCard].tags}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex gap-4 lg:gap-6 h-[75vh] min-h-[600px] items-stretch">
            {visibleCards.map((card, displayIndex) => {
              const isFirst = displayIndex === 0;
              return (
                <div
                  key={card.originalIndex}
                  onClick={() => handleCardClick(card.originalIndex)}
                  className={`
                    relative overflow-hidden rounded-2xl cursor-pointer
                    transition-all duration-1000 ease-[cubic-bezier(0.25,1,0.5,1)]
                    bg-[#1E293B] dark:bg-[#1E293B] light:bg-white
                    border hover:shadow-2xl group
                    ${isFirst
                      ? 'flex-[2] border-[#3B82F6]/40 shadow-[0_0_30px_rgba(59,130,246,0.1)]'
                      : 'flex-1 border-[#3D4B5E] hover:border-[#3B82F6]/30'
                    }
                  `}
                >
                  {/* Progress indicator */}
                  {isFirst && (
                    <div className="absolute bottom-0 left-0 w-1.5 h-full bg-[#3D4B5E]/40 overflow-hidden z-20">
                      <div className="absolute bottom-0 left-0 w-full bg-[#3B82F6] transition-all duration-100 ease-linear" style={{ height: `${progress}%` }} />
                    </div>
                  )}

                  <div className="p-6 lg:p-8 flex flex-col gap-5 h-full relative z-10">
                    <div>
                      <div className={`text-5xl lg:text-6xl font-black transition-all duration-700 ${isFirst ? 'text-[#3B82F6]/20 scale-110' : 'text-white/10 scale-90'}`}>
                        {card.number}
                      </div>
                      <h3 className={`text-lg lg:text-2xl font-bold transition-colors duration-500 mt-2 ${isFirst ? 'text-white' : 'text-[#CBD5E1]'}`}>
                        {card.title}
                      </h3>
                    </div>

                    <div className={`flex-1 flex flex-col justify-between transition-all duration-700 ${isFirst ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10 pointer-events-none'}`}>
                      <p className="text-[#CBD5E1] text-sm lg:text-base leading-relaxed">{card.description}</p>
                      <div className="w-full h-40 lg:h-48 overflow-hidden rounded-xl border border-[#3D4B5E] my-4">
                        <img src={card.image} alt={card.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
                      </div>
                      <div className="text-[9px] lg:text-[10px] font-bold tracking-widest text-[#3B82F6] uppercase">{card.tags}</div>
                    </div>
                  </div>

                  {!isFirst && (
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500 z-0" />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pagination Dots */}
      <div className="flex gap-2 mt-8">
        {cards.map((_, i) => (
          <button
            key={i}
            onClick={() => { setActiveCard(i); setProgress(0); }}
            className={`h-1.5 transition-all duration-500 rounded-full cursor-pointer ${
              activeCard === i ? 'w-8 bg-[#3B82F6]' : 'w-2 bg-[#3D4B5E] hover:bg-[#CBD5E1]/40'
            }`}
            aria-label={`Go to service ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default ExpandingCards;